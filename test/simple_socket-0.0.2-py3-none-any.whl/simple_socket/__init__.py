# install with
# pip3 install git+https://github.com/GrantGMiller/simple_tcp.git@master#egg=simple_tcp
from .tcp_client import SimpleTCPClient