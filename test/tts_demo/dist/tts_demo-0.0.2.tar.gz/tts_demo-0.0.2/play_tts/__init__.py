from .test_playTTS import *

name = "tts_demo"

__all__ = {
    'test_playTTS',
}
